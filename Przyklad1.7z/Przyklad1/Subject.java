public class Subject {
    private String name;
    private int numberOfHours;
    private Teacher teacher;

    public Teacher getTeacher() {
        return teacher;
    }
    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public Subject(String name, int numberOfHours) {
        this.name = name;
        this.numberOfHours = numberOfHours;

    }
    public Subject(String name, int numberOfHours, Teacher techer) {
        this.name = name;
        this.numberOfHours = numberOfHours;
        this.teacher=techer;

    }
    public Subject() {
        this.name = "";
        this.numberOfHours = 0;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfHours() {
        return numberOfHours;
    }

    public void setNumberOfHours(int numberOfHours) {
        this.numberOfHours = numberOfHours;
    }

    @Override
    public String toString() {
        return "Subject{" +
                "name='" + name + '\'' +
                ", numberOfHours=" + numberOfHours +
                '}';
    }
}
