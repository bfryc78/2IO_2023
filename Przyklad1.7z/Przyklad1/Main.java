import java.util.*;

public class Main {
    public static void main(String[] args)
    {
        // Tworzenie obiektu nauczyciela
        Teacher teacher = new Teacher("Barbara ", "Fryc", 20, 240 );
        // Wywołanie metody introduceYourself dla nauczyciela
      //  teacher.introduceYourself();


        List <Person> osoby = new ArrayList<Person>();
        osoby.add(teacher);
        osoby.add(new Student("Olaf", "Pałka", 23));

        for( var p:osoby)
        {
            p.introduceYourself();
        }

    }
}
