// Klasa dziedzicząca Teacher z klasy abstrakcyjnej Person
class Teacher extends Person {
    private int teaching_hours;

    public Teacher() {
        super(" ", "", 240);
        teaching_hours=240;
    }
    public Teacher(String name, String surname, int age, int teaching_hours) {
        super(name, surname, age);
        this.teaching_hours = teaching_hours;
    }

    // Implementacja metody introduceYourself dla nauczyciela
  /*  @Override
    public void introduceYourself() {
        System.out.println("I am a teacher. My name is " + name + " " +surname );
    }*/
}
