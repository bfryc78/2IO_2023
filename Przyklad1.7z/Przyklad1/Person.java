 class Person {
    protected String name;
    protected String surname;
    protected int age;

    public Person(String name,  String surname,int age) {
        this.name = name;
        this.surname=surname;
        this.age = age;
    }
    public Person() {

    }

    // Metoda abstrakcyjna, która będzie implementowana przez klasy dziedziczące
   // public abstract void introduceYourself();

     public void introduceYourself() {
         System.out.println("I am a person. My name is " + name + " " +surname );
     }
}