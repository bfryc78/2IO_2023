import java.util.ArrayList;
import java.util.List;

public class Student extends Person {

    List <Subject> subjects;
    public Student(String name, String surname, int age)
    {
        super(name, surname, age);
        subjects = new ArrayList<Subject>();
    }
    public void addSubject(String name, int numberOfHours, Teacher teacher)
    {
        subjects.add(new Subject(name, numberOfHours, teacher));

    };
    @Override
    public void introduceYourself() {
        System.out.println("I am a student. My name is " + name + " " +surname );
    }
}
